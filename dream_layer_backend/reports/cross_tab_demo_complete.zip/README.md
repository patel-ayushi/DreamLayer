# DreamLayer Generation Report

Generated on: 2025-08-09 23:11:13

## Report Contents

This report bundle contains a comprehensive snapshot of your DreamLayer image generation session.

### Files Included

- **`results.csv`**: Complete metadata for all generated images
  - Contains 3 image records
  - Includes prompts, settings, model information, and file paths
  - All paths are relative to this report bundle

- **`config.json`**: System configuration and available models
  - Current DreamLayer settings
  - Available models and their details
  - Directory structure information

- **`grids/`**: Organized image collections
    - `img2img/`: Images generated via img2img
  - `txt2img/`: Images generated via txt2img
  - `extras/`: Images generated via extras

- **`README.md`**: This documentation file

### Using This Report

1. **CSV Analysis**: Import `results.csv` into any spreadsheet application or data analysis tool
2. **Image Review**: Browse the `grids/` folders to review generated images
3. **Configuration Backup**: Use `config.json` to restore or replicate your setup
4. **Path Verification**: All paths in the CSV resolve to files within this bundle

### Schema Information

The `results.csv` file follows a standardized schema with the following required columns:
- `id`, `filename`, `relative_path`, `prompt`, `negative_prompt`
- `model_name`, `sampler_name`, `steps`, `cfg_scale`, `width`, `height`
- `seed`, `timestamp`, `generation_type`, `batch_index`

Optional columns include denoising strength, LoRA models, ControlNet information, and file sizes.

### Support

For questions about this report format or DreamLayer functionality, refer to the project documentation.
